package problema;

public enum FormatPesoAresta {

	UPPER_ROW,LOWER_DIAG_ROW;

}
